OPTION A (computer): Android Studio -> File > Open this folder -> Build > Build APK(s).
OPTION B (no Android Studio): create a free GitHub repository, upload ALL files in this folder
(including the hidden .github folder), open the Actions tab -> "Build APK" -> run.
When it finishes, download "MaatladitheContact-APK" from the run page, unzip it, and install app-debug.apk on the phone.
