package com.maatladithe.contact

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.provider.ContactsContract
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale

data class C(val name: String, val num: String, val photo: String?)

// ---------- Telugu/English sound matching (all on-device) ----------
private val CONS = "కk ఖk గg ఘg ఙn చc ఛc జj ఝj ఞn టt ఠt డd ఢd ణn తt థt దd ధd నn పp ఫp బb భb మm యy రr ఱr లl ళl వv శs షs సs హh"
    .split(" ").associate { it[0] to it.substring(1) }
private val MATRA = "ాa ిi ీi ుu ూu ృr ెe ేe ైa ొo ోo ౌa".split(" ").associate { it[0] to it.substring(1) }
private val VOW = "అa ఆa ఇi ఈi ఉu ఊu ఋr ఎe ఏe ఐa ఒo ఓo ఔa ంn ఃh ఁn".split(" ").associate { it[0] to it.substring(1) }

fun tr(s: String): String {
    val sb = StringBuilder(); var pend = false
    for (ch in s) {
        when {
            CONS[ch] != null -> { if (pend) sb.append('a'); sb.append(CONS[ch]); pend = true }
            MATRA[ch] != null -> { pend = false; sb.append(MATRA[ch]) }
            ch == '్' -> pend = false
            else -> { if (pend) { sb.append('a'); pend = false }; sb.append(VOW[ch] ?: ch.toString()) }
        }
    }
    if (pend) sb.append('a')
    return sb.toString()
}

fun skel(s: String): String {
    var t = tr(s.lowercase())
    for ((a, b) in listOf("sh" to "s", "ch" to "c", "th" to "t", "dh" to "d", "kh" to "k", "gh" to "g", "bh" to "b",
        "ph" to "p", "ck" to "k", "w" to "v", "z" to "j", "q" to "k", "x" to "ks")) t = t.replace(a, b)
    val o = StringBuilder()
    for (ch in t) if (ch in 'a'..'z' && ch !in "aeiou" && (o.isEmpty() || o.last() != ch)) o.append(ch)
    return o.toString()
}

fun sim(a: String, b: String): Double {
    if (a.isEmpty() || b.isEmpty()) return 0.0
    var p = IntArray(b.length + 1) { it }
    for (i in 1..a.length) {
        val c = IntArray(b.length + 1); c[0] = i
        for (j in 1..b.length) c[j] = minOf(p[j] + 1, c[j - 1] + 1, p[j - 1] + if (a[i - 1] == b[j - 1]) 0 else 1)
        p = c
    }
    return 1.0 - p[b.length].toDouble() / maxOf(a.length, b.length)
}

fun score(q: String, name: String): Double {
    val fs = skel(name)
    var best = maxOf(sim(q, fs), name.split(" ", "-", ".").maxOfOrNull { sim(q, skel(it)) } ?: 0.0)
    if (q.length >= 2 && fs.contains(q)) best = maxOf(best, 0.85)
    return best
}

val STOP = setOf("కి", "కు", "ఫోన్", "ఫోను", "చేయాలి", "చేయండి", "చేయి", "చెయ్యి", "చెయ్యాలి", "చేయాలా", "కాల్", "నంబర్",
    "నెంబర్", "నంబరు", "నెంబరు", "చూపించు", "చూపించండి", "నాకు", "కావాలి", "దయచేసి", "ని", "గారికి", "call", "phone", "number")

fun extract(s: String): String = s.split(" ").map { it.trim() }.filter { it.isNotEmpty() && it.lowercase() !in STOP }
    .map { if (it.length > 3 && (it.endsWith("కి") || it.endsWith("కు"))) it.dropLast(2).trimEnd('\u200c', '\u200d') else it }
    .joinToString(" ")

// ---------- Activity ----------
class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private lateinit var tts: TextToSpeech
    private var ttsOk = false
    private val prefs by lazy { getSharedPreferences("p", 0) }
    var screen by mutableStateOf("main")
    var heard by mutableStateOf("")
    var msg by mutableStateOf("ఎవరికి ఫోన్ చేయాలో చెప్పండి")
    var failed by mutableStateOf(false)
    var results by mutableStateOf(listOf<C>())
    var sel by mutableStateOf<C?>(null)
    var all by mutableStateOf(listOf<C>())
    var recents by mutableStateOf(listOf<C>())
    var favs by mutableStateOf(setOf<String>())

    private val perm = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        if (hasContacts()) { loadContacts(); screen = "main"; say("మీరు ఎవరికి ఫోన్ చేయాలి?") }
    }
    private val speech = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val l = r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
        if (!l.isNullOrEmpty()) handle(l) else { failed = true; screen = "main"; say("మీరు చెప్పింది వినపడలేదు. మళ్లీ ప్రయత్నించండి.") }
    }

    private fun hasContacts() = checkSelfPermission(Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED

    override fun onInit(st: Int) {
        ttsOk = st == TextToSpeech.SUCCESS && tts.setLanguage(Locale("te", "IN")) >= TextToSpeech.LANG_AVAILABLE
    }

    fun say(t: String) { msg = t; if (ttsOk) tts.speak(t, TextToSpeech.QUEUE_FLUSH, null, "u") }

    private fun loadContacts() {
        val out = linkedMapOf<String, C>()
        contentResolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER,
                ContactsContract.CommonDataKinds.Phone.PHOTO_THUMBNAIL_URI), null, null, null)?.use {
            while (it.moveToNext()) {
                val n = it.getString(0) ?: continue; val p = it.getString(1) ?: continue
                out.putIfAbsent(n + "|" + p.filter { c -> c.isDigit() || c == '+' }, C(n, p, it.getString(2)))
            }
        }
        all = out.values.sortedBy { it.name.lowercase() }
    }

    fun listen() {
        failed = false
        if (!hasContacts()) { screen = "perm"; return }
        say("మీరు ఎవరికి ఫోన్ చేయాలి?")
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "te-IN").putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "te-IN")
            .putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5).putExtra(RecognizerIntent.EXTRA_PROMPT, "పేరు చెప్పండి")
        try { speech.launch(i) } catch (e: Exception) { failed = true; say("ఈ ఫోన్‌లో వాయిస్ సౌకర్యం లేదు. సహాయం నొక్కండి.") }
    }

    private fun handle(l: List<String>) {
        heard = l[0]
        if (heard.contains("మళ్లీ చెప్పు") || heard.contains("మళ్ళీ చెప్పు")) { sel?.let { speakContact(it) } ?: listen(); return }
        var found = listOf<C>()
        for (cand in l) {
            val q = skel(extract(cand)); if (q.isEmpty()) continue
            val sc = all.map { it to score(q, it.name) }.filter { it.second >= 0.7 }.sortedByDescending { it.second }
            if (sc.isNotEmpty()) { val top = sc[0].second; found = sc.filter { top < 0.95 || it.second >= top - 0.1 }.map { it.first }.take(6); break }
        }
        results = found
        when {
            found.isEmpty() -> { failed = true; screen = "main"; say("ఈ పేరు మీ కాంటాక్ట్స్‌లో దొరకలేదు. మళ్లీ ప్రయత్నించండి.") }
            found.size == 1 -> { sel = found[0]; screen = "result"; speakContact(found[0], true) }
            else -> { screen = "choose"; say("ఒకటి కంటే ఎక్కువ పేర్లు దొరికాయి. సరైన పేరును ఎంచుకోండి.") }
        }
    }

    fun speakContact(c: C, ask: Boolean = false) =
        say("${c.name} అనే పేరు దొరికింది. నంబర్ ${c.num.filter { it.isDigit() }.toList().joinToString(" ")}." + if (ask) " ఈ నంబర్‌కు ఫోన్ చేయాలా?" else "")

    fun call(c: C) {
        recents = (listOf(c) + recents.filter { it.num != c.num }).take(10)
        prefs.edit().putString("r", recents.joinToString("\n") { "${it.name}\t${it.num}\t${it.photo ?: ""}" }).apply()
        val granted = checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED
        startActivity(Intent(if (granted) Intent.ACTION_CALL else Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(c.num))))
    }

    fun toggleFav(c: C) { favs = if (c.num in favs) favs - c.num else favs + c.num; prefs.edit().putStringSet("f", favs).apply() }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        tts = TextToSpeech(this, this)
        favs = prefs.getStringSet("f", emptySet())!!.toSet()
        recents = (prefs.getString("r", "") ?: "").split("\n").filter { it.isNotBlank() }.map {
            val p = it.split("\t"); C(p[0], p.getOrElse(1) { "" }, p.getOrNull(2)?.ifBlank { null }) }
        if (hasContacts()) loadContacts()
        if (!prefs.getBoolean("seen", false)) screen = "tut"
        setContent { App(this) }
    }

    fun finishTutorial() { prefs.edit().putBoolean("seen", true).apply(); screen = if (hasContacts()) "main" else "perm" }
    fun requestPerms() = perm.launch(arrayOf(Manifest.permission.READ_CONTACTS, Manifest.permission.CALL_PHONE))
    fun dial(n: String) = startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(n))))
    override fun onDestroy() { tts.shutdown(); super.onDestroy() }
}

// ---------- UI ----------
val NAVY = Color(0xFF1A237E); val GREEN = Color(0xFF1B8E3E); val ORANGE = Color(0xFFD84315); val GREY = Color(0xFF455A64)

@Composable fun Btn(t: String, c: Color = NAVY, h: Int = 90, onClick: () -> Unit) =
    Button(onClick, Modifier.fillMaxWidth().height(h.dp), colors = ButtonDefaults.buttonColors(containerColor = c), shape = RoundedCornerShape(20.dp)) {
        Text(t, fontSize = 26.sp, fontWeight = FontWeight.Bold, color = Color.White, textAlign = TextAlign.Center) }

@Composable fun T(t: String, s: Int = 24, w: FontWeight = FontWeight.Normal) =
    Text(t, fontSize = s.sp, fontWeight = w, color = Color.Black, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth(), lineHeight = (s * 1.4).sp)

@Composable fun Photo(u: String?) {
    val ctx = LocalContext.current
    val bmp = remember(u) { try { u?.let { BitmapFactory.decodeStream(ctx.contentResolver.openInputStream(Uri.parse(it)))?.asImageBitmap() } } catch (e: Exception) { null } }
    if (bmp != null) Image(bmp, null, Modifier.size(120.dp).clip(CircleShape))
    else Box(Modifier.size(120.dp).clip(CircleShape).background(Color(0xFFC5CAE9)), contentAlignment = Alignment.Center) { Text("👤", fontSize = 60.sp) }
}

@Composable fun Row1(c: C, a: MainActivity) = Button({ a.sel = c; a.screen = "result"; a.speakContact(c, true) },
    Modifier.fillMaxWidth().heightIn(min = 110.dp), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE8EAF6)), shape = RoundedCornerShape(20.dp)) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text((if (c.num in a.favs) "⭐ " else "") + c.name, fontSize = 30.sp, fontWeight = FontWeight.Bold, color = Color.Black)
        Text(c.num, fontSize = 30.sp, color = NAVY) } }

@Composable fun App(a: MainActivity) {
    BackHandler(a.screen != "main") { a.screen = "main" }
    MaterialTheme { Surface(Modifier.fillMaxSize(), color = Color.White) {
        Column(Modifier.fillMaxSize().systemBarsPadding().padding(20.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            when (a.screen) {
                "tut" -> {
                    T("స్వాగతం!", 36, FontWeight.Bold)
                    T("1️⃣ మైక్ బటన్ నొక్కండి.", 28); T("2️⃣ ఫోన్ చేయాల్సిన వారి పేరు చెప్పండి.", 28)
                    T("3️⃣ పేరు, నంబర్ చూసి ఆకుపచ్చ బటన్ నొక్కండి.", 28)
                    T("పేరు గుర్తించడానికి ఇంటర్నెట్ అవసరం కావచ్చు. మీ కాంటాక్ట్స్ ఎవరికీ పంపబడవు.", 22)
                    Btn("సరే, మొదలుపెడదాం", GREEN, 110) { a.finishTutorial() }
                }
                "perm" -> {
                    T("అనుమతి కావాలి", 34, FontWeight.Bold)
                    T("మీ ఫోన్‌లోని పేర్లు వెతకడానికి 'కాంటాక్ట్స్' అనుమతి కావాలి. తరువాత వచ్చే ప్రశ్నకు 'అనుమతించు' నొక్కండి.", 26)
                    Btn("అనుమతి ఇవ్వండి", GREEN, 110) { a.requestPerms() }
                }
                "main" -> {
                    T("నా ఫోన్ కాంటాక్ట్స్", 36, FontWeight.Bold)
                    Btn("🎤 పేరు చెప్పండి", ORANGE, 170) { a.listen() }
                    T(a.msg, 26, FontWeight.Medium)
                    if (a.heard.isNotBlank()) T("మీరు చెప్పింది: ${a.heard}", 26, FontWeight.Bold)
                    if (a.failed) Btn("🔢 నంబర్ నొక్కండి", GREY) { a.screen = "keypad" }
                    Btn("పరిచయాలు చూడండి") { a.screen = "list" }
                    Btn("చివరిగా వెతికిన పేరు") { a.screen = "recent" }
                    Btn("సహాయం", GREY) { a.screen = "help" }
                }
                "result" -> a.sel?.let { c ->
                    Photo(c.photo); T(c.name, 38, FontWeight.Bold); T(c.num, 46, FontWeight.ExtraBold)
                    Btn("📞 ఫోన్ చేయండి", GREEN, 140) { a.call(c) }
                    Btn("🔊 మళ్లీ వినండి", NAVY) { a.speakContact(c, true) }
                    Btn("మళ్లీ పేరు చెప్పండి", ORANGE) { a.listen() }
                    Btn(if (c.num in a.favs) "⭐ ముఖ్యమైనది నుండి తీసివేయండి" else "⭐ ముఖ్యమైనదిగా పెట్టండి", GREY) { a.toggleFav(c) }
                    Btn("వెనుకకు", GREY, 70) { a.screen = "main" }
                }
                "choose" -> {
                    T("సరైన పేరును ఎంచుకోండి", 30, FontWeight.Bold)
                    a.results.forEach { Row1(it, a) }
                    Btn("మళ్లీ పేరు చెప్పండి", ORANGE) { a.listen() }
                }
                "list" -> {
                    T("పరిచయాలు", 32, FontWeight.Bold)
                    if (a.all.isEmpty()) T("కాంటాక్ట్స్ లేవు లేదా అనుమతి ఇవ్వలేదు.", 24)
                    a.all.sortedBy { if (it.num in a.favs) 0 else 1 }.forEach { Row1(it, a) }
                    Btn("వెనుకకు", GREY, 70) { a.screen = "main" }
                }
                "recent" -> {
                    T("చివరిగా వెతికిన పేర్లు", 32, FontWeight.Bold)
                    if (a.recents.isEmpty()) T("ఇంకా ఎవరినీ వెతకలేదు.", 24)
                    a.recents.forEach { Row1(it, a) }
                    Btn("వెనుకకు", GREY, 70) { a.screen = "main" }
                }
                "help" -> {
                    T("సహాయం", 34, FontWeight.Bold)
                    T("మైక్ బటన్ నొక్కి, ఉదాహరణకు 'అమ్మ' లేదా 'మోహన్ కి ఫోన్ చేయాలి' అని చెప్పండి.", 26)
                    T("తప్పు పేరు వస్తే ఫోన్ చేయవద్దు. 'మళ్లీ పేరు చెప్పండి' నొక్కండి.", 26)
                    T("తెలుగు మాట వినపడకపోతే, ఫోన్ సెట్టింగ్స్‌లో Google తెలుగు వాయిస్ ఇన్‌స్టాల్ చేయమని మీ కుటుంబ సభ్యులను అడగండి.", 22)
                    Btn("🔢 నంబర్ నొక్కండి", GREY) { a.screen = "keypad" }
                    Btn("ట్యుటోరియల్ మళ్లీ చూడండి", NAVY) { a.screen = "tut" }
                    Btn("వెనుకకు", GREY, 70) { a.screen = "main" }
                }
                "keypad" -> {
                    var n by remember { mutableStateOf("") }
                    val te = "౦౧౨౩౪౫౬౭౮౯"
                    T(if (n.isEmpty()) "నంబర్ నొక్కండి" else n.map { te[it - '0'] }.joinToString(""), 44, FontWeight.Bold)
                    listOf("123", "456", "789").forEach { r -> Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        r.forEach { d -> Box(Modifier.weight(1f)) { Btn(te[d - '0'].toString(), NAVY, 90) { n += d } } } } }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Box(Modifier.weight(1f)) { Btn("⌫", ORANGE, 90) { n = n.dropLast(1) } }
                        Box(Modifier.weight(1f)) { Btn(te[0].toString(), NAVY, 90) { n += "0" } }
                        Box(Modifier.weight(1f)) { Btn("🗑", GREY, 90) { n = "" } } }
                    Btn("📞 ఫోన్ చేయండి", GREEN, 120) { if (n.isNotEmpty()) a.dial(n) }
                    Btn("వెనుకకు", GREY, 70) { a.screen = "main" }
                }
            }
        } } }
}
