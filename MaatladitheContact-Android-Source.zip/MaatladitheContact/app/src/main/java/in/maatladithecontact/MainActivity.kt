package in.maatladithecontact

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.ContactsContract
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import coil.compose.AsyncImage
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import java.text.Normalizer
import java.util.Locale

data class Person(val id: String, val name: String, val number: String, val photo: String? = null)

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        setContent { MaatladitheApp(this) }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = tts?.setLanguage(Locale("te", "IN"))
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                tts?.language = Locale("te")
            }
        }
    }

    fun speak(text: String) {
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "telugu_voice")
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}

@Composable
fun MaatladitheApp(activity: MainActivity) {
    val context = activity
    val prefs = remember { context.getSharedPreferences("local_data", 0) }
    var hasContactsPermission by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED)
    }
    var people by remember { mutableStateOf<List<Person>>(emptyList()) }
    var resultPeople by remember { mutableStateOf<List<Person>>(emptyList()) }
    var spoken by remember { mutableStateOf("") }
    var screen by remember { mutableStateOf("home") }
    var status by remember { mutableStateOf("ఎవరికి ఫోన్ చేయాలో చెప్పండి") }
    var keypad by remember { mutableStateOf("") }
    var recent by remember { mutableStateOf(prefs.getString("recent", "") ?: "") }
    var favorites by remember { mutableStateOf(prefs.getStringSet("favorites", emptySet())?.toSet() ?: emptySet()) }
    var selected by remember { mutableStateOf<Person?>(null) }
    var listening by remember { mutableStateOf(false) }

    fun loadContacts() {
        if (!hasContactsPermission) return
        val list = mutableListOf<Person>()
        val cursor = context.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(
                ContactsContract.CommonDataKinds.Phone.CONTACT_ID,
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER,
                ContactsContract.CommonDataKinds.Phone.PHOTO_URI
            ), null, null, ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " COLLATE LOCALIZED ASC"
        )
        cursor?.use {
            val idCol = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.CONTACT_ID)
            val nameCol = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
            val numCol = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
            val photoCol = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.PHOTO_URI)
            while (it.moveToNext()) {
                val id = it.getString(idCol) ?: continue
                val name = it.getString(nameCol) ?: continue
                val number = it.getString(numCol) ?: continue
                val photo = if (photoCol >= 0) it.getString(photoCol) else null
                list.add(Person(id, name, number, photo))
            }
        }
        people = list.distinctBy { it.id + it.number }
    }

    val contactsPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        hasContactsPermission = granted
        if (granted) loadContacts() else {
            status = "పరిచయాలు చూడటానికి అనుమతి ఇవ్వండి"
            activity.speak(status)
        }
    }
    val audioPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) startTeluguListening(activity,
            onStart = { listening = true; status = "వింటున్నాను... పేరు చెప్పండి" },
            onResult = { text ->
                listening = false
                spoken = text
                val matches = findMatches(text, people)
                selected = null
                resultPeople = matches
                screen = "results"
                if (matches.isEmpty()) {
                    status = "ఈ పేరు మీ పరిచయాల్లో దొరకలేదు. మళ్లీ ప్రయత్నించండి."
                    activity.speak(status)
                } else if (matches.size > 1) {
                    status = "ఒకటి కంటే ఎక్కువ పేర్లు దొరికాయి. సరైన పేరును ఎంచుకోండి."
                    activity.speak(status)
                } else {
                    selected = matches.first()
                    recent = matches.first().name
                    prefs.edit().putString("recent", recent).apply()
                    status = "${matches.first().name} అనే పేరు దొరికింది."
                    activity.speak(status + " ఈ నంబర్‌కు ఫోన్ చేయాలా?")
                }
            },
            onError = { listening = false; status = "మళ్లీ ప్రయత్నించండి"; activity.speak("మీ మాట వినిపించలేదు. మళ్లీ పేరు చెప్పండి.") }
        ) else {
            status = "మాట వినడానికి అనుమతి ఇవ్వండి"
            activity.speak(status)
        }
    }

    LaunchedEffect(hasContactsPermission) { if (hasContactsPermission) loadContacts() }

    MaterialTheme(colorScheme = lightColorScheme(
        primary = Color(0xFF075E35),
        secondary = Color(0xFF155E75),
        background = Color(0xFFF7FAF7),
        surface = Color.White
    )) {
        Surface(Modifier.fillMaxSize(), color = Color(0xFFF7FAF7)) {
            Column(
                Modifier.fillMaxSize().padding(horizontal = 18.dp, vertical = 14.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("మాట్లాడితే కాంటాక్ట్", fontSize = 27.sp, fontWeight = FontWeight.Bold, color = Color(0xFF123D2A))
                Spacer(Modifier.height(8.dp))
                when (screen) {
                    "home" -> {
                        Text("నా ఫోన్ కాంటాక్ట్స్", fontSize = 25.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(24.dp))
                        Button(
                            onClick = {
                                if (!hasContactsPermission) contactsPermission.launch(Manifest.permission.READ_CONTACTS)
                                else audioPermission.launch(Manifest.permission.RECORD_AUDIO)
                            },
                            modifier = Modifier.fillMaxWidth().height(116.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF075E35)),
                            shape = RoundedCornerShape(24.dp)
                        ) {
                            Icon(Icons.Default.Mic, null, modifier = Modifier.size(42.dp))
                            Spacer(Modifier.width(12.dp))
                            Text(if (listening) "వింటున్నాను..." else "పేరు చెప్పండి", fontSize = 29.sp, fontWeight = FontWeight.Bold)
                        }
                        Spacer(Modifier.height(14.dp))
                        Text("ఎవరికి ఫోన్ చేయాలో చెప్పండి", fontSize = 21.sp, textAlign = TextAlign.Center)
                        Spacer(Modifier.height(22.dp))
                        BigButton("పరిచయాలు చూడండి") {
                            if (!hasContactsPermission) contactsPermission.launch(Manifest.permission.READ_CONTACTS)
                            else { loadContacts(); screen = "contacts" }
                        }
                        BigButton("చివరిగా వెతికిన పేరు") {
                            if (recent.isNotBlank()) {
                                spoken = recent; resultPeople = findMatches(recent, people); screen = "results"
                            } else { status = "ఇంకా ఎవరినీ వెతకలేదు"; activity.speak(status) }
                        }
                        BigButton("సంఖ్యలతో వెతకండి") { keypad = ""; screen = "keypad" }
                        BigButton("సహాయం") { screen = "help" }
                        Spacer(Modifier.weight(1f))
                        Text(status, fontSize = 17.sp, color = Color.DarkGray, textAlign = TextAlign.Center)
                    }
                    "results" -> {
                        Text("మీరు చెప్పిన పేరు", fontSize = 23.sp, fontWeight = FontWeight.Bold)
                        Text(spoken, fontSize = 25.sp, color = Color(0xFF075E35))
                        Spacer(Modifier.height(12.dp))
                        if (resultPeople.isEmpty()) {
                            Text("పేరు దొరకలేదు", fontSize = 24.sp)
                        } else {
                            LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                items(resultPeople) { person ->
                                    ContactCard(person, favorites.contains(person.id), onChoose = {
                                        selected = person
                                        recent = person.name
                                        prefs.edit().putString("recent", recent).apply()
                                        activity.speak("${person.name}. ${person.number}")
                                    }, onFavorite = {
                                        favorites = if (favorites.contains(person.id)) favorites - person.id else favorites + person.id
                                        prefs.edit().putStringSet("favorites", favorites).apply()
                                    })
                                }
                            }
                            selected?.let { p ->
                                Text("ఎంచుకున్న పేరు: ${p.name}", fontSize = 18.sp)
                                Text(p.number, fontSize = 31.sp, fontWeight = FontWeight.Bold)
                                BigButton("ఫోన్ చేయండి", green = true) { openDialer(context, p.number) }
                                BigButton("పేరు, నంబర్ మళ్లీ వినండి") { activity.speak("${p.name}. ${p.number}") }
                            }
                        }
                        BigButton("మళ్లీ పేరు చెప్పండి") { screen = "home"; audioPermission.launch(Manifest.permission.RECORD_AUDIO) }
                        BigButton("మొదటి పేజీ") { selected = null; screen = "home" }
                    }
                    "contacts" -> {
                        Text("మీ పరిచయాలు", fontSize = 25.sp, fontWeight = FontWeight.Bold)
                        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(people) { person ->
                                ContactCard(person, favorites.contains(person.id), onChoose = {
                                    selected = person; resultPeople = listOf(person); spoken = person.name; screen = "results"
                                    activity.speak("${person.name}. ${person.number}")
                                }, onFavorite = {
                                    favorites = if (favorites.contains(person.id)) favorites - person.id else favorites + person.id
                                    prefs.edit().putStringSet("favorites", favorites).apply()
                                })
                            }
                        }
                        BigButton("మొదటి పేజీ") { screen = "home" }
                    }
                    "help" -> {
                        Text("ఎలా ఉపయోగించాలి?", fontSize = 25.sp, fontWeight = FontWeight.Bold)
                        Text(
                            "१. పేరు చెప్పండి బటన్ నొక్కండి.\n२. ఎవరి పేరు కావాలో తెలుగులో చెప్పండి.\n३. సరైన పేరు, నంబర్ చూసుకోండి.\n४. ఫోన్ చేయండి నొక్కితే ఫోన్ తెరుచుకుంటుంది.\n\nపరిచయాలు చదవడానికి, మీ మాట వినడానికి అనుమతులు అడుగుతాము. మీ పరిచయాలు ఫోన్ బయటకు పంపబడవు. మాట గుర్తించడానికి ఇంటర్నెట్ అవసరం కావచ్చు.",
                            fontSize = 20.sp, lineHeight = 31.sp
                        )
                        Spacer(Modifier.weight(1f))
                        BigButton("మొదటి పేజీ") { screen = "home" }
                    }
                    "keypad" -> {
                        Text("ఫోన్ నంబర్ టైప్ చేయండి", fontSize = 24.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(18.dp))
                        Text(keypad.ifBlank { " " }, fontSize = 34.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(12.dp))
                        val rows = listOf(listOf("1", "2", "3"), listOf("4", "5", "6"), listOf("7", "8", "9"), listOf("తుడవు", "0", "⌫"))
                        rows.forEach { row ->
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                row.forEach { digit ->
                                    Button(
                                        onClick = {
                                            keypad = when (digit) {
                                                "తుడవు" -> ""
                                                "⌫" -> keypad.dropLast(1)
                                                else -> keypad + digit
                                            }
                                        },
                                        modifier = Modifier.weight(1f).height(66.dp),
                                        shape = RoundedCornerShape(14.dp)
                                    ) { Text(digit, fontSize = 25.sp, fontWeight = FontWeight.Bold) }
                                }
                            }
                            Spacer(Modifier.height(7.dp))
                        }
                        BigButton("డయలర్ తెరవండి", green = true) {
                            if (keypad.isNotBlank()) openDialer(context, keypad)
                        }
                        Spacer(Modifier.weight(1f))
                        BigButton("మొదటి పేజీ") { screen = "home" }
                    }
                }
            }
        }
    }
}

@Composable
fun BigButton(label: String, green: Boolean = false, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp).heightIn(min = 58.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = if (green) Color(0xFF16803C) else Color(0xFF174A68)
        ),
        shape = RoundedCornerShape(16.dp)
    ) { Text(label, fontSize = 21.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center) }
}

@Composable
fun ContactCard(person: Person, favorite: Boolean, onChoose: () -> Unit, onFavorite: () -> Unit) {
    Card(Modifier.fillMaxWidth().clickable { onChoose() }, shape = RoundedCornerShape(16.dp)) {
        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            if (!person.photo.isNullOrBlank()) {
                AsyncImage(
                    model = person.photo,
                    contentDescription = "పరిచయ చిత్రం",
                    modifier = Modifier.size(54.dp),
                    contentScale = ContentScale.Crop
                )
                Spacer(Modifier.width(12.dp))
            }
            Column(Modifier.weight(1f)) {
                Text(person.name, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Text(person.number, fontSize = 20.sp)
            }
            IconButton(onClick = onFavorite) {
                Icon(if (favorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                    contentDescription = "ఇష్టమైన పరిచయం", tint = Color(0xFFB3261E))
            }
        }
    }
}

fun openDialer(context: android.content.Context, number: String) {
    val intent = Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", number, null))
    context.startActivity(intent)
}

fun startTeluguListening(
    activity: Activity,
    onStart: () -> Unit,
    onResult: (String) -> Unit,
    onError: () -> Unit
) {
    if (!SpeechRecognizer.isRecognitionAvailable(activity)) {
        onError()
        return
    }
    val recognizer = SpeechRecognizer.createSpeechRecognizer(activity)
    recognizer.setRecognitionListener(object : android.speech.RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) = onStart()
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onError(error: Int) { recognizer.destroy(); onError() }
        override fun onResults(results: Bundle?) {
            val words = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            recognizer.destroy()
            val best = words?.firstOrNull()
            if (best.isNullOrBlank()) onError() else onResult(best)
        }
        override fun onPartialResults(partialResults: Bundle?) {}
        override fun onEvent(eventType: Int, params: Bundle?) {}
    })
    val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        putExtra(RecognizerIntent.EXTRA_LANGUAGE, "te-IN")
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "te-IN")
        putExtra(RecognizerIntent.EXTRA_ONLY_RETURN_LANGUAGE_PREFERENCE, false)
        putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
        putExtra(RecognizerIntent.EXTRA_PROMPT, "ఎవరికి ఫోన్ చేయాలో చెప్పండి")
    }
    try { recognizer.startListening(intent) } catch (_: Exception) { recognizer.destroy(); onError() }
}

fun normalize(s: String): String {
    val noMarks = Normalizer.normalize(s.lowercase(Locale.ROOT), Normalizer.Form.NFD)
        .replace(Regex("\\p{M}+"), "")
    return noMarks.replace(Regex("[^\\p{L}\\p{N}]"), "")
}

fun findMatches(phrase: String, contacts: List<Person>): List<Person> {
    val cleaned = phrase
        .replace(Regex("(కి ఫోన్ చేయాలి|కు ఫోన్ చేయాలి|నంబర్ చూపించు|నంబర్ చెప్పు|కి కాల్ చేయి|కు కాల్ చేయి|ఫోన్ చేయాలి|ఫోన్ చేయి|కాల్ చేయాలి|కాల్ చేయి|నంబర్|ఫోన్|కాల్|చూపించు|చెప్పు|చేయాలి|చేయి)"), " ")
        .trim()
    val query = normalize(cleaned)
    if (query.isBlank()) return emptyList()
    val scored = contacts.map { p ->
        val name = normalize(p.name)
        val score = when {
            name == query -> 100
            name.contains(query) || query.contains(name) -> 80
            name.split(Regex("\\s+")).any { it == query } -> 75
            else -> tokenSimilarity(query, name)
        }
        p to score
    }.filter { it.second >= 65 }.sortedByDescending { it.second }
    if (scored.isEmpty()) return emptyList()
    val best = scored.first().second
    // Show close alternatives; never silently choose among similar matches.
    return scored.filter { it.second >= maxOf(65, best - 12) }.map { it.first }.distinctBy { it.id + it.number }.take(12)
}

fun tokenSimilarity(a: String, b: String): Int {
    if (a.length < 2 || b.length < 2) return 0
    val common = a.toSet().intersect(b.toSet()).size.toDouble()
    val ratio = common / maxOf(a.toSet().size, b.toSet().size)
    return (ratio * 70).toInt()
}
